#include <cassert>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <ctime>

std::string encrypt_decrypt(const std::string& source, const std::string& key)
{
    const auto key_length = key.length();
    const auto source_length = source.length();

    assert(key_length > 0);
    assert(source_length > 0);

    std::string output = source;

    for (size_t i = 0; i < source_length; ++i)
    {
        // XOR operation between source and key characters
        output[i] = source[i] ^ key[i % key_length];
    }

    assert(output.length() == source_length);

    return output;
}

std::string read_file(const std::string& filename)
{
    // Open the file for reading
    std::ifstream file(filename);

    // Use a stringstream to read the contents of the file into a string
    std::stringstream buffer;
    buffer << file.rdbuf();

    // Return the string containing the file contents
    return buffer.str();
}

std::string get_student_name(const std::string& string_data)
{
    std::string student_name;

    // Find the first newline character
    size_t pos = string_data.find('\n');
    if (pos != std::string::npos)
    {
        // Extract the substring before the newline as the student name
        student_name = string_data.substr(0, pos);
    }

    return student_name;
}

void save_data_file(const std::string& filename, const std::string& student_name, const std::string& key, const std::string& data)
{
    // Open the file for writing
    std::ofstream file(filename);
    if (file)
    {
        // Write the student name to the file
        file << student_name << "\n";

        // Get the current timestamp
        std::time_t now = std::time(nullptr);

        // Write the timestamp to the file in the format yyyy-mm-dd
        file << std::put_time(std::localtime(&now), "%Y-%m-%d") << "\n";

        // Write the key to the file
        file << key << "\n";

        // Write the data to the file
        file << data;

        // Close the file
        file.close();
    }
    else
    {
        std::cerr << "Error saving data to file: " << filename << std::endl;
    }
}

int main()
{
    std::cout << "Encryption Decryption Test!" << std::endl;

    const std::string file_name = "inputdatafile.txt";
    const std::string encrypted_file_name = "encrypteddatafile.txt";
    const std::string decrypted_file_name = "decrypteddatafile.txt";

    // Read the contents of the input file into a string
    const std::string source_string = read_file(file_name);

    const std::string key = "password";

    // Extract the student name from the source string
    const std::string student_name = get_student_name(source_string);

    // Encrypt the source string using the key
    const std::string encrypted_string = encrypt_decrypt(source_string, key);

    // Save the encrypted string to a file
    save_data_file(encrypted_file_name, student_name, key, encrypted_string);

    // Decrypt the encrypted string using the key
    const std::string decrypted_string = encrypt_decrypt(encrypted_string, key);

    // Save the decrypted string to a file
    save_data_file(decrypted_file_name, student_name, key, decrypted_string);

    std::cout << "Read File: " << file_name << " - Encrypted To: " << encrypted_file_name << " - Decrypted To: " << decrypted_file_name << std::endl;
}
